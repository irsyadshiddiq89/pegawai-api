<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\PegawaiController;

Route::apiResource('pegawais', PegawaiController::class);
