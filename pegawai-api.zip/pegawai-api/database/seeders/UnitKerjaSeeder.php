<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\UnitKerja;

class UnitKerjaSeeder extends Seeder
{
    public function run(): void
    {
        UnitKerja::insert([
            [
                'nama_unit' => 'Bidang Kurikulum',
                'skpd_id' => 1,
            ],
            [
                'nama_unit' => 'Bidang Kepegawaian',
                'skpd_id' => 1,
            ],
        ]);
    }
}
