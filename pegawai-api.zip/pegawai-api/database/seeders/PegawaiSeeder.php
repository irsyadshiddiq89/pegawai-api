<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Pegawai;

class PegawaiSeeder extends Seeder
{
    public function run(): void
    {
        Pegawai::create([
            'nip' => '198001012024001',
            'nama_lengkap' => 'Budi Santoso',
            'jenis_kelamin' => 'Laki-laki',
            'jabatan_id' => 1,
            'skpd_id' => 1,
            'unit_kerja_id' => 1,
            'nama_golongan' => 'III/A',
            'nama_pangkat' => 'Penata Muda',
            'alamat_lengkap' => 'Jl. Merdeka No. 1',
        ]);
    }
}
