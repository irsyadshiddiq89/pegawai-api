<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Skpd;

class SkpdSeeder extends Seeder
{
    public function run(): void
    {
        Skpd::insert([
            ['skpd' => 'Dinas Pendidikan'],
            ['skpd' => 'Dinas Kesehatan'],
        ]);
    }
}
