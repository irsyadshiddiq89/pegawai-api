<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Jabatan;

class JabatanSeeder extends Seeder
{
    public function run(): void
    {
        Jabatan::insert([
            ['jabatan' => 'Kepala Dinas'],
            ['jabatan' => 'Sekretaris'],
            ['jabatan' => 'Staff'],
        ]);
    }
}
