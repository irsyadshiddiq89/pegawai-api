<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pegawais', function (Blueprint $table) {
            $table->id();
            $table->string('nip')->unique();
            $table->string('nama_lengkap');
            $table->string('jenis_kelamin');

            $table->foreignId('jabatan_id') ->constrained('jabatans')   ->cascadeOnDelete();

            $table->foreignId('skpd_id')    ->constrained('skpds')  ->cascadeOnDelete();

            $table->foreignId('unit_kerja_id')  ->constrained('unit_kerjas')    ->cascadeOnDelete();

            $table->string('nama_golongan');
            $table->string('nama_pangkat');
            $table->text('alamat_lengkap');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pegawais');
    }
};
