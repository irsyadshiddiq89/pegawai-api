<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Pegawai;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Http\Requests\StorePegawaiRequest;
use App\Http\Requests\UpdatePegawaiRequest;

class PegawaiController extends Controller
{
    // GET /api/pegawais
    public function index()
    {
        return Pegawai::with(['jabatan', 'skpd', 'unitKerja'])->get();
    }

    // POST /api/pegawais
    public function store(StorePegawaiRequest $request)
    {
        $pegawai = Pegawai::create($request->validated());

        return response()->json([
            'message' => 'Pegawai berhasil ditambahkan',
            'data' => $pegawai->load(['jabatan', 'skpd', 'unitKerja'])
        ], 201);
    }

    // PUT /api/pegawais/{pegawai}
    public function update(UpdatePegawaiRequest $request, Pegawai $pegawai)
    {
        $pegawai->update($request->validated());

        return response()->json([
            'message' => 'Pegawai berhasil diperbarui',
            'data' => $pegawai->load(['jabatan', 'skpd', 'unitKerja'])
        ]);
    }

    // DELETE /api/pegawais/{pegawai}
    public function destroy(Pegawai $pegawai)
    {
        $pegawai->delete();

        return response()->json([
            'message' => 'Pegawai berhasil dihapus'
        ]);
    }

    // GET /api/pegawais/{pegawai} (opsional, untuk detail)
    public function show(Pegawai $pegawai)
    {
        return response()->json([
            'success' => true,
            'data' => $pegawai->load(['jabatan', 'skpd', 'unitKerja'])
        ]);
    }
}
