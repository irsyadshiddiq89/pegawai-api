<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdatePegawaiRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $pegawaiId = $this->route('pegawai');

        return [
            'nip' => [
                'required',
                'string',
                Rule::unique('pegawais', 'nip')->ignore($pegawaiId),
            ],
            'nama_lengkap' => ['required', 'string'],
            'jenis_kelamin' => ['required', Rule::in(['Laki-laki', 'Perempuan'])],

            'jabatan_id' => ['required', 'exists:jabatans,id'],
            'skpd_id' => ['required', 'exists:skpds,id'],
            'unit_kerja_id' => ['required', 'exists:unit_kerjas,id'],

            'nama_golongan' => ['required', 'string'],
            'nama_pangkat' => ['required', 'string'],
            'alamat_lengkap' => ['required', 'string'],
        ];
    }
}
