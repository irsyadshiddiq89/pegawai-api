<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Skpd;
use App\Models\Pegawai;

class UnitKerja extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_unit',
        'skpd_id',
    ];

    public function skpd()
    {
        return $this->belongsTo(Skpd::class);
    }

    public function pegawais()
    {
        return $this->hasMany(Pegawai::class);
    }
}
